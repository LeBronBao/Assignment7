package homework;


public class Node {
	private int id;
	private Object data;
	private Node parent;
	private Node[] children = new Node[2];
	private int lSubTreeHeight;
	private int rSubTreeHeight;
	private int balanceFactor;
	public Node(Object x){
		data = x;
		children[0] = children[1] = null;
		balanceFactor = 0;
	}
	public int getId() {
		return id;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
	public Node getParent() {
		return parent;
	}
	public void setParent(Node parent) {
		this.parent = parent;
	}
	public Node[] getChildren() {
		return children;
	}
	public Node getChild(int id){
		Node[] children = this.getChildren();
		return children[id];
	}
	public void setChildren(Node[] children) {
		this.children = children;
	}
	public void setChild(Node child, int id){
		this.children[id] = child;
	}
	//����������߶�
	public int getlSubTreeHeight() {
		Node[] chrilden = this.getChildren();
		if(children[0]==null){
			lSubTreeHeight=0;
			return lSubTreeHeight;
		}
		else{
			int left = children[0].lSubTreeHeight+1;
			int right = children[0].rSubTreeHeight+1;
			if(left>right){
				return left;
			}
			else{
				return right;
			}
		}
	}
	public int getrSubTreeHeight() {
		Node[] chrilden = this.getChildren();
		if(children[0]==null){
			rSubTreeHeight=0;
			return rSubTreeHeight;
		}
		else{
			int left = children[1].lSubTreeHeight+1;
			int right = children[1].rSubTreeHeight+1;
			if(left>right){
				return left;
			}
			else{
				return right;
			}
		}
	}
	//ƽ������
	public int getBalanceFactor() {
		return this.getlSubTreeHeight()-this.getrSubTreeHeight();
	}
	public void setBalanceFactor(int b){
		this.balanceFactor = b;
	}

}
