package homework;

import javax.swing.JTree;

public class AVLTree implements IAVLTree {
	public Node root;
	private boolean unBalance;
	private boolean shorter;
	public AVLTree(){
		root = null;
	}
	private Node get(Node x,int id){
		if(x==null){
			return x;
		}
		else{
			int m = x.getId()-id;
			if(m>0){
				return get(x.getChild(0),id);
			}
			else{
				return get(x.getChild(1),id);
			}
		}
	}
	@Override
	public Node get(int id) {
		
		return get(root,id);
	}
	private void insert(Node newNode,Node root){
		if(newNode.getId()<root.getId()){
			if(root.getChild(0)==null){
				root.setChild(newNode, 0);
				unBalance = true;
				root.setBalanceFactor(root.getBalanceFactor()+1);
			}else{
				insert(newNode,root.getChild(0));
				if(unBalance){
					switch(root.getBalanceFactor()){
					case -1:
						root.setBalanceFactor(0);
						unBalance = false;
						break;
					case 0:
						root.setBalanceFactor(1);
						break;
					case 1:
						LRotation(root);
					}
				}
			}
		}
		else{
			if(root.getChild(1) ==null){
				root.setChild(newNode, 1);
				unBalance = true;
				root.setBalanceFactor(root.getBalanceFactor()-1);
			}
			else{
				insert(newNode,root.getChild(1));
				if(unBalance){
					switch(root.getBalanceFactor()){
					case -1:
						RRotation(root);
						break;
					case 0:
						root.setBalanceFactor(-1);
						break;
					case 1:
						root.setBalanceFactor(0);
						unBalance = false;
						break;
					}
				}
			}
		}
	}
	@Override
	public void insert(Node newNode) {
		   insert(newNode,root);
	}
	
	//����ת����
	public void LRotation(Node p){
		Node t;
		Node l = p.getChild(0);
		Node r = p.getChild(1);
		Node s = p.getParent();
		if(l.getBalanceFactor()==1){         //LL��ת
			p.setChild(l.getChild(1),0);
			l.setChild(p, 1);
			s.setChild(l, 0);
			root = l;
			p.setBalanceFactor(0);
			l.setBalanceFactor(0);
		}
		else{                           //LR��ת
			t = r.getChild(1);
			l.setChild(r.getChild(0), 1);
			t.setChild(l, 0);
			p.setChild(t.getChild(1), 0);
			t.setChild(p, 1);
			root = t;
			s.setChild(r.getChild(0), 0);

			switch(t.getBalanceFactor()){
			case 1: p.setBalanceFactor(-1);
					l.setBalanceFactor(0);
					break;
			case 0: p.setBalanceFactor(0);
					l.setBalanceFactor(0);
					break;
			case -1:p.setBalanceFactor(0);
					l.setBalanceFactor(1);
					break;
			}
			r.getChild(0).setBalanceFactor(0);
		}
		root.setBalanceFactor(0);
		unBalance = false;
	}
	//����ת����
	public void RRotation(Node p){
		Node t;
		Node r = p.getChild(1);
		Node s = p.getParent();
		if(r.getBalanceFactor()!=1){
			p.setChild(r.getChild(0), 1);
			r.setChild(p,0);
			s.setChild(r, 0);
			root = r;
			p.setBalanceFactor(0);
			r.setBalanceFactor(0);
		}
		else{
			t = r.getChild(0);
			r.setChild(t.getChild(1), 0);
			t.setChild(r, 1);
			p.setChild(t.getChild(0), 1);
			t.setChild(p, 0);
			root = t;
			s.setChild(r.getChild(1), 0);
			switch(t.getBalanceFactor()){
			case 1: 
					p.setBalanceFactor(0);
					r.setBalanceFactor(-1);
					break;
			case 0: 
					p.setBalanceFactor(0);
					r.setBalanceFactor(0);
					break;
			case -1:
					p.setBalanceFactor(1);
					r.setBalanceFactor(0);
					break;
			}
			t.setBalanceFactor(0);
		}
		root.setBalanceFactor(0);
		unBalance = false;
	}

	
	
	
	
	

	@Override
	public void delete(int id) {
		Node temp = get(id);
		if(temp==null) return;
		else if(temp.getChildren()==null){
			
		}
	}

	@Override
	public JTree printTree() {

		return null;
	}

}
